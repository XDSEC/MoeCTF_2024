package top.sxrhhh.servlet.user;

import top.sxrhhh.pojo.User;
import top.sxrhhh.service.user.UserServiceImpl;
import top.sxrhhh.util.Constants;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * TODO
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/7 下午7:11
 * @version 1.0
 * @since 17
 */
public class LoginServlet extends HttpServlet {

    // servlet: 控制层，调用业务层代码

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("LoginServlet--start....");


        // 获取用户名和密码
        String userCode = req.getParameter("userCode");
        String userPassword = req.getParameter("userPassword");

        // 和数据库中的密码进行对比, 调用业务层
        UserServiceImpl userService = new UserServiceImpl();
        User user = userService.login(userCode, userPassword); // 已经查出登陆的人了

        if (user != null) { // 存在此人，可以登陆
            // 将用户的信息放在 session 中
            req.getSession().setAttribute(Constants.USER_SESSION, user);
            // 跳转到主页
            resp.sendRedirect("jsp/frame.jsp");
        } else { // 查无此人, 无法登陆
            // 转发回登陆页面, 顺便提示错误
            req.setAttribute("error", "用户名或密码不正确test");
            req.getRequestDispatcher("login.jsp").forward(req, resp);

        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
