package top.sxrhhh.util;

/**
 * TODO
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/7 下午7:16
 * @version 1.0
 * @since 17
 */
public class Constants {
    public static final String USER_SESSION = "userSession";
}
