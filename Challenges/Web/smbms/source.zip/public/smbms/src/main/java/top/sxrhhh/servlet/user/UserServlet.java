package top.sxrhhh.servlet.user;

import com.alibaba.fastjson.JSONArray;
import com.mysql.cj.util.StringUtils;
import top.sxrhhh.pojo.Role;
import top.sxrhhh.pojo.User;
import top.sxrhhh.service.role.RoleServiceImpl;
import top.sxrhhh.service.user.UserService;
import top.sxrhhh.service.user.UserServiceImpl;
import top.sxrhhh.util.Constants;
import top.sxrhhh.util.PageSupport;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 实现 servlet 复用
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/8 下午5:31
 * @version 1.0
 * @since 17
 */
public class UserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("method");
        if ("savepwd".equals(method)) {
            this.updatePwd(req, resp);
        } else if ("pwdmodify".equals(method)) {
            this.pwdModify(req, resp);
        } else if ("query".equals(method)) {
            this.query(req, resp);
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    // 修改密码
    public void updatePwd(HttpServletRequest req, HttpServletResponse resp) {
        // 从 session 里面拿 id
        Object o = req.getSession().getAttribute(Constants.USER_SESSION);

        String newpassword = req.getParameter("newpassword");

        boolean flag = false;

        if (o != null && !StringUtils.isNullOrEmpty(newpassword)) {
            UserService userService = new UserServiceImpl();
            flag = userService.updatePwd(((User) o).getId(), newpassword);
            if (flag) {
                req.setAttribute("message", "修改密码成功，请退出，使用新密码登陆");
                // 密码修改成功，移除当前 session
                req.getSession().removeAttribute(Constants.USER_SESSION);
            } else {
                req.setAttribute("message", "密码修改失败");
            }
        } else {
            req.setAttribute("message", "新密码有问题");
        }

        try {
            req.getRequestDispatcher("pwdmodify.jsp").forward(req, resp);
        } catch (ServletException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // 验证旧密码, session 中有密码
    public void pwdModify(HttpServletRequest req, HttpServletResponse resp) {
        // 获取 id
        Object o = req.getSession().getAttribute(Constants.USER_SESSION);
        String oldpassword = req.getParameter("oldpassword");

        // 万能的Map: 结果集
        Map<String, String> resultMap = new HashMap<String, String>();


        if (o == null) { // session 失效
            resultMap.put("result", "sessionerror");
        } else if (StringUtils.isNullOrEmpty(oldpassword)) { // 输入密码为空
            resultMap.put("result", "error");
        } else {
            String userPassword = ((User) o).getUserPassword(); // session 中用户的密码
            if (oldpassword.equals(userPassword)) {
                // 与旧密码一致
                resultMap.put("result", "true");
            } else {
                resultMap.put("result", "false");
            }
        }

        try {
            resp.setContentType("application/json");
            PrintWriter writer = resp.getWriter();
            // JSONArray
            writer.write(JSONArray.toJSONString(resultMap));
            writer.flush();
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    // 重点、难点
    public void query(HttpServletRequest req, HttpServletResponse resp) {

        // 查询用户列表

        // 从前端获取数据
        String queryUserName = req.getParameter("queryName");
        String temp = req.getParameter("queryUserRole");
        String pageIndex = req.getParameter("pageIndex");
        int queryUserRole = 0;

        // 获取用户列表
        UserServiceImpl userService = new UserServiceImpl();
        List<User> userList = null;
        // 第一次一定是第一页, 页面大小固定
        int pageSize = 5; // 配置文件
        int currentPageNo = 1;

//        if (queryUserName == null) {
//            queryUserName = "";
//        }

        if (temp != null && !temp.isEmpty()) {
            queryUserRole = Integer.parseInt(temp); // 给查询赋值
        }

        if (pageIndex != null && !pageIndex.isEmpty()) {
            try {
                currentPageNo = Integer.parseInt(pageIndex);
            } catch (NumberFormatException e) {
                try {
//                    resp.sendRedirect("/error.jsp");
                    req.getRequestDispatcher("/error.jsp").forward(req, resp);
                    return;
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                } catch (ServletException ex) {
                    throw new RuntimeException(ex);
                }
//                throw new RuntimeException(e);
            }
        }

        // 获取用户的总数 (分页: 上一页/下一页)
        int totalCount = userService.getUserCount(queryUserName, queryUserRole);
        // 总页数支持
        PageSupport pageSupport = new PageSupport();
        pageSupport.setCurrentPageNo(currentPageNo);
        pageSupport.setPageSize(pageSize);
        pageSupport.setTotalCount(totalCount);

        int totalPageCount = pageSupport.getTotalPageCount();

        // 控制首页和尾页
        if (currentPageNo < 1) {
            currentPageNo = 1;
        } else if (currentPageNo > totalPageCount) {
            currentPageNo = totalPageCount;
        }

        // 获取用户列表展示
        userList = userService.getUserList(queryUserName, queryUserRole, currentPageNo, pageSize);
        req.setAttribute("userList", userList);

        RoleServiceImpl roleService = new RoleServiceImpl();
        List<Role> roleList = roleService.getRoleList();
        req.setAttribute("roleList", roleList);

        req.setAttribute("totalPageCount", totalPageCount);
        req.setAttribute("totalCount", totalCount);
        req.setAttribute("currentPageNo", currentPageNo);
        req.setAttribute("queryUserName", queryUserName);
        req.setAttribute("queryUserRole", queryUserRole);


        // 返回前端
        try {
            req.getRequestDispatcher("userlist.jsp").forward(req, resp);
        } catch (ServletException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


}
