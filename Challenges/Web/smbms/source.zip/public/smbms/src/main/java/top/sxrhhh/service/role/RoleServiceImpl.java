package top.sxrhhh.service.role;

import org.junit.Test;
import top.sxrhhh.dao.BaseDao;
import top.sxrhhh.dao.role.RoleDao;
import top.sxrhhh.dao.role.RoleDaoImpl;
import top.sxrhhh.pojo.Role;

import java.sql.Array;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * TODO
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/9 下午8:26
 * @version 1.0
 * @since 17
 */
public class RoleServiceImpl implements RoleService {

    // 引入 Dao
    private RoleDao roleDao;
    public RoleServiceImpl() {
        roleDao = new RoleDaoImpl();
    }


    @Override
    public List<Role> getRoleList() {

        Connection connection = null;
        List<Role> roleList = null;
        try {
            connection = BaseDao.getConnection();
            roleList = roleDao.getRoleList(connection);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            BaseDao.closeResource(connection, null, null);
        }

        return roleList;

    }

    @Test
    public void test() {
        RoleServiceImpl roleService = new RoleServiceImpl();
        List<Role> roleList = roleService.getRoleList();
        for (Role role : roleList) {
            System.out.println(role.getRoleName());
        }
    }
}
