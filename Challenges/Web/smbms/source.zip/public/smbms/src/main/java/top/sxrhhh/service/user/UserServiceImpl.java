package top.sxrhhh.service.user;

import org.junit.Test;
import top.sxrhhh.dao.BaseDao;
import top.sxrhhh.dao.user.UserDao;
import top.sxrhhh.dao.user.UserDaoImpl;
import top.sxrhhh.pojo.User;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * TODO
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/7 下午7:01
 * @version 1.0
 * @since 17
 */
public class UserServiceImpl implements UserService {
    // 业务层都会调用 dao 层，所以要引入 dao 层
    private UserDao userDao;
    public UserServiceImpl() {
        userDao = new UserDaoImpl();
    }


    @Override
    public User login(String userCode, String password) {
        Connection connection = null;
        User user = null;

        try {
            connection = BaseDao.getConnection();
            // 通过业务层调用对应的具体的数据库操作
            user = userDao.getLoginUser(connection, userCode);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            BaseDao.closeResource(connection, null, null);
        }
        if (user != null && user.getUserPassword() != null && user.getUserPassword().equals(password)) {
            return user;
        } else {
            return null;
        }
    }

    @Override
    public boolean updatePwd(int id, String pwd) {
        Connection connection = null;
        boolean flag = false;


        // 修改密码
        try {
            connection = BaseDao.getConnection();
            if (userDao.updatePwd(connection, id, pwd) > 0) {
                flag = true;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            BaseDao.closeResource(connection, null, null);

        }
        return flag;
    }

    // 查询记录数
    @Override
    public int getUserCount(String username, int userRole) {
        Connection connection = null;
        int count = 0;
        try {

            connection = BaseDao.getConnection();
            count = userDao.getUserCount(connection, username, userRole);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            BaseDao.closeResource(connection, null, null);
        }

        return count;

    }

    //根据条件查询用户列表
    @Override
    public List<User> getUserList(String queryUserName, int queryUserRole, int currentPageNo, int pageSize) {
        Connection con = null;
        List<User> userList = null;
//        System.out.println("queryUserName ----> " + queryUserName);
//        System.out.println("queryUserName ----> " + queryUserRole);
//        System.out.println("currentPageNo ----> " + currentPageNo);
//        System.out.println("pageSize ----> " + pageSize);
        try {
            con = BaseDao.getConnection();
            userList = userDao.getUserList(con, queryUserName, queryUserRole, currentPageNo, pageSize);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            BaseDao.closeResource(con, null, null);
        }
        return userList;
    }

    @Test
    public void test(){
        UserService userService = new UserServiceImpl();
        int userCount = userService.getUserCount(null, 0);
        System.out.println(userCount);

    }


}
