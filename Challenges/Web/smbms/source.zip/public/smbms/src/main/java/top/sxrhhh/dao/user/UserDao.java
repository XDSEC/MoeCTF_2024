package top.sxrhhh.dao.user;

import top.sxrhhh.pojo.Role;
import top.sxrhhh.pojo.User;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * TODO
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/7 下午6:03
 * @version 1.0
 * @since 17
 */
public interface UserDao {
    // 得到登陆的用户
    public User getLoginUser(Connection connection, String userCode) throws SQLException;

    // 修改当前用户密码
    public int updatePwd(Connection connection, int id, String password) throws SQLException;

    // 查询用户总数
    public int getUserCount(Connection connection, String username, int userRole) throws SQLException;

    // 获取用户列表
    List<User> getUserList(Connection connection, String userName, int userRole, int currentPageNo, int pageSize) throws Exception;

}
