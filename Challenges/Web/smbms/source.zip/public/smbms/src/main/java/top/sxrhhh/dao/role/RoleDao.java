package top.sxrhhh.dao.role;

import top.sxrhhh.pojo.Role;

import java.sql.Connection;
import java.util.List;

/**
 * TODO
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/9 下午8:23
 * @version 1.0
 * @since 17
 */
public interface RoleDao {
    // 获取角色列表
    List<Role> getRoleList(Connection connection) throws Exception;
}
