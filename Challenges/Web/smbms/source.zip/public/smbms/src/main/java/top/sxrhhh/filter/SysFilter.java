package top.sxrhhh.filter;

import top.sxrhhh.pojo.User;
import top.sxrhhh.util.Constants;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * TODO
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/7 下午11:03
 * @version 1.0
 * @since 17
 */
public class SysFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        // 从 session 中获取用户
        User user = (User) req.getSession().getAttribute(Constants.USER_SESSION);

        if (user == null) { // 已经移除或注销或未登录
            resp.sendRedirect(req.getContextPath() + "/error.jsp");
        }

        chain.doFilter(request, response);

    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}
