package top.sxrhhh.filter;

import javax.servlet.*;
import java.io.IOException;

/**
 * TODO
 * <p>
 *
 * @author sxrhhh
 * 创建于: 2024/8/7 下午5:49
 * @version 1.0
 * @since 17
 */
public class CharacterEncodingFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        // 这行代码会导致 css 和 js 文件失效
//        response.setContentType("text/html;charset=UTF-8");

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}
